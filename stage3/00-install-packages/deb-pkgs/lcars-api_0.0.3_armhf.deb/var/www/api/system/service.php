<?php
require 'servicelist.php';

$commands = [
  "start",
  "stop",
  "restart",
  "enable",
  "disable"
];

$service = $_GET["service"];
$command = $_GET["cmd"];

$service_ok = false;
$command_ok = false;

if (in_array($service, $services)) {
  $service_ok = true;
} else {
  echo '{ "success": false, "services": [';
  $first = true;
  foreach($services as $item) {
    if($first) {
      $first = false;
    } else {
      echo ",";
    }
    echo '"' . $item . '"';
  }
  echo '], "service": "' . $service . '" }';
  exit(0);
}

if (in_array($command, $commands)) {
  $command_ok = true;
} else {
  echo '{ "success": false, "commands": [';
  $first = true;
  foreach($commands as $item) {
    if($first) {
      $first = false;
    } else {
      echo ",";
    }
    echo '"' . $item . '"';
  }
  echo '] }';
  exit(0);
}


  $answer = shell_exec("sudo systemctl.sh " . $command . " " . $service );
  echo '{ "success": true }';
?>
