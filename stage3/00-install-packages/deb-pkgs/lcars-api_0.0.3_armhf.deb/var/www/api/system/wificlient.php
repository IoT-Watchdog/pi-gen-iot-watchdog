<?php

$wpafile = "/etc/wpa_supplicant/wpa_supplicant.conf";

$command = "get";
if(isset($_GET['cmd'])) {
  $command = $_GET["cmd"]; // rm | add
} 

function read_return_wpasuppplicant() {
  $networks = shell_exec('cat '.$wpafile.'|egrep \'^network|^[[:space:]]*ssid="|^[[:space:]]*psk|^}\'|sed -z -e \'s/}/},/g\' -e \'s/network=//g\' -e \'s/[[:space:]]ssid="/  "ssid": "/g\' -e \'s/\n[[:space:]]psk=/,\n  "psk": /g\' -e \'s/},\n$/}\n/\'');
  return("[\n" . $networks . "]\n");
}

if($command == "get") {
  $networks = read_return_wpasuppplicant()
  echo '{ "success": true, "networks": '. "\n" . $networks . "\n }";
  exit(0);
}

if($command == "rm") {
  if(isset($_GET['ssid'])) {
    $ssid = $_GET["ssid"];
    if(! $ssid) {
      echo '{ "success": false, "error": "ssid parameter empty" }';
      exit(0);
    }
  } else {
    echo '{ "success": false, "error": "ssid parameter not set" }';
    exit(0);
  }

  shell_exec('sed -z \'s/network={\n[[:space:]]*ssid="'.$ssid.'"\n[[:space:]]*psk="[^"]*"\n[[:space:]]*key_mgmt=WPA-PSK\n}\n\n//\' -i ' . $wpafile);
  echo '{ "success": true, "deleted": "'.$ssid.'", "networks": '.read_return_wpasuppplicant().' }';
  exit(0);
}

if($command == "add") {

  if(isset($_GET['ssid'])) {
    $ssid = $_GET["ssid"];
    if(! $ssid) {
      echo '{ "success": false, "error": "ssid parameter empty" }';
      exit(0);
    }
  } else {
    echo '{ "success": false, "error": "ssid parameter not set" }';
    exit(0);
  }
  if(isset($_GET['pw'])) {
    $pw = $_GET["pw"];
    if(! $pw) {
      echo '{ "success": false, "error": "password parameter empty" }';
      exit(0);
    }
  } else {
    echo '{ "success": false, "error": "password parameter not set" }';
    exit(0);
  }

  $content = "network={\n\tssid=\"".$ssid."\"\n\tpsk=\"".$pw."\"\n\tscan_ssid=1\n\tkey_mgmt=WPA-PSK\n}";
  shell_exec('echo "'.$content.'" >> ' . $wpafile);
  echo '{ "success": true, "added": "'.$ssid.'", "networks": '.read_return_wpasuppplicant().' }';
}

?>
