<?php
shell_exec("/usr/bin/sudo shutdown -h now");
echo '{ "success": true, "shutdown": "halt" }';
?>
