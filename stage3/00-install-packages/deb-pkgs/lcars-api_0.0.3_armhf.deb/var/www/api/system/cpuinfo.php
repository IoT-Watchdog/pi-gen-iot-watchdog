<?php
$arch = exec("uname -m");

$cpuinfo = shell_exec('cat /proc/cpuinfo');
$infoarray = explode("\n",$cpuinfo);
$processors = 0;

foreach($infoarray as $line) {
  if(!strncmp("processor",$line,9))
    $processors++;
}

$rpi_model = exec("cat /proc/device-tree/model");

  echo '{ "success": true, ';
  echo '  "architecture": "'.$arch.'",';
  echo '  "cpu": "'.trim($rpi_model).'",';
  echo '  "cpus": "'.$processors.'" }';
?>
