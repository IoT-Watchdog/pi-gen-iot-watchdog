<?php

if(isset($_GET['set'])) {
  $targetdate = $_GET["set"];
} else {
  $targetdate = "";
}

function readDate() {
  $hwdate = trim(shell_exec("sudo hwclock --get 2>/dev/null"));
  $swdate = trim(shell_exec('date "+%Y-%m-%d %H:%M:%S"'));
  echo '{ "success": true, "hwdate": "';
  echo $hwdate . '", "swdate": "' . $swdate . '" }' . "\n";
}

if($targetdate !== "") {
  shell_exec("sudo hwclock --set --date '" . $targetdate . "'");
  shell_exec("sudo hwclock --hctosys" );
}

readDate();


?>
