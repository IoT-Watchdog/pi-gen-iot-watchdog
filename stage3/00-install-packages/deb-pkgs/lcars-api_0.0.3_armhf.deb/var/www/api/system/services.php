<?php
require 'servicelist.php';

echo "{\n  \"services\": [\n";

$first = true;
foreach ($services as $service) {

  if($first) {
    $first = false;
  } else {
    echo ",";
  }
  echo "    {\n";

  $answer = shell_exec("sudo systemctl-status.sh " . $service . ".service 2>/dev/null");
  $lines_answer = explode("\n",$answer);
  if(sizeof($lines_answer) > 2) {

    $namedesc = substr($lines_answer[0],2);
    $ndarray = explode(" - ", $namedesc);
    $name = rtrim($ndarray[0]);
    if(substr_compare($name, ".service", -8) === 0) {
      $name = substr($name,0,-8);
    }
    $description = ltrim($ndarray[1]);
    echo '      "name": "' . $name . "\",\n"; // service name
    echo '      "description": "' . $description . "\",\n";
    if(strpos($description, "ensor") !== false) {
      echo "      \"sensor\": true,\n";
    }

    echo "      \"installed\": true,\n";

    $onboot = trim(explode(";", $lines_answer[1])[1]);
    $enabled = ($onboot == 'enabled') ? 'true' : 'false';
    if($onboot == 'generated') {
      if(file_exists("/run/systemd/generator.late/multi-user.target.wants/" . $name . ".service")) {
        $enabled = 'true';
      }
    }
    echo '      "onboot": ' . $enabled . ",\n"; // on boot

    $currentstatus = ltrim(explode(")",substr($lines_answer[2],10))[0]);
    $class = "false"; // should be undefined?
    if(0 == strncmp("active (running)", $currentstatus, 11)) {
      $class = "true";
    }
    if(0 == strncmp("failed", $currentstatus, 6)) {
      $class = "false";
    }
    echo '      "running": '.$class.",\n";
    echo '      "runningText": "' . $currentstatus . "\",\n"; // current status

    echo '      "pids": "'; // PID
    foreach($lines_answer as $line) {
      if(0 == strncmp("Main PID:", ltrim($line),9)) {
        echo trim(explode(":", $line)[1]);
      }
    }
    echo "\"\n"; // PID

  } else {
    echo '      "name": "' . $service . "\",\n";
    echo "      \"installed\": false\n";
  }
  echo "    }\n";
}
echo "  ]\n";
echo "}";
?>
