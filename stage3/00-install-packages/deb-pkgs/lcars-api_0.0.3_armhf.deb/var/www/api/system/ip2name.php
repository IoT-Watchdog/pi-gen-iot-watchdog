<?php

if(isset($_GET['ip'])) {
	$ip = $_GET['ip'];
} else {
	echo '{ "success": false }';
	exit(0);
}

$ans = trim(shell_exec("host '" . $ip . "'"));

$last_word_start = strrpos($ans, ' ') + 1; // +1 so we don't include the space in our result
$last_word = substr($ans, $last_word_start);

echo '{ "' . $ip . '": "' . $last_word . "\" }\n";


?>
