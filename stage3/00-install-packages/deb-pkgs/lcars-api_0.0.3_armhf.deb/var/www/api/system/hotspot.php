<?php

$hotspotfile = "/etc/NetworkManager/system-connections/Accesspoint";

$command = "get";

function get_ssid() {
	global $hotspotfile;
	return trim(explode("=", shell_exec('grep "^ssid=" ' . $hotspotfile))[1]);
}
function get_pass() {
	global $hotspotfile;
	return trim(explode("=", shell_exec('grep "^psk=" ' . $hotspotfile))[1]);
}

if(isset($_GET['ssid'])) {
	$new_ssid=$_GET['ssid'];
	shell_exec('sed -i "s/^ssid=.*/ssid='.$new_ssid.'/" ' . $hotspotfile);
}

if(isset($_GET['psk'])) {
	$new_psk=$_GET['psk'];
	shell_exec('sed -i "s/^psk=.*/psk='.$new_psk.'/" ' . $hotspotfile);
}

echo '{ "success": true, "ssid": "' . get_ssid() . '", "pass": "' . get_pass() . '" }';

?>
