<?php
$hn = shell_exec("/bin/hostname");
echo '{ "success": true, "hostname": "'.trim($hn).'" }';
?>
