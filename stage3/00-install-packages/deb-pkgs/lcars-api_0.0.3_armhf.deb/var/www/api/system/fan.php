<?php 

if (isset($_GET["fanspeed"])) {
  $fanspeed = $_GET["fanspeed"];
  $ifs = strval($fanspeed);

  if( $ifs <= 100 && $ifs >= 0) {
    $cmd = "sudo /usr/local/bin/ut-change-config.sh fan fanspeed " . $fanspeed;
 #   echo $cmd;
    $ret = system($cmd);
   # echo $ret;
  } else {
    echo '{ "error": "param fanspeed [0-100] out of range" }';
  }
}

$fsfile = '/run/sensors/fan/last';
if(file_exists($fsfile)) {
  $newspeed = "";
  if(isset($_GET["fanspeed"])) {
    $newspeed = '"newspeed":'.$fanspeed.', ';
  }
  $fs = explode(" ", file_get_contents($fsfile))[1];
  echo '{ "success": true, '.$newspeed.'"fanspeed": ' . trim($fs) . ' }';
} else {
  echo '{ "success": false }';
}
?>
