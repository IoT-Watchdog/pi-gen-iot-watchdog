<?php
if( isset($argc) and $argc>1)
	  parse_str(implode('&',array_slice($argv, 1)), $_GET);

$commands = [
  "show",
  "up",
  "down",
  "modify"
];

if(isset($_GET["cmd"])) {
	$command = $_GET["cmd"];
} else {
	echo '{ "success": false, "required_params": "cmd" }';
	return;
}
if(isset($_GET["con"])) {
	$con = $_GET["con"];
} else {
	$con = "";
}

# $key = $_GET["k"];
# $value = $_GET["v"];
if(isset($_GET["ssid"])) {
	$ssid = $_GET["ssid"];
} else {
	$ssid = "";
}

if(isset($_GET["pass"])) {
	$pass = $_GET["pass"];
} else {
	$pass = "";
}

$command_ok = false;

if (in_array($command, $commands)) {
  $command_ok = true;
} else {
  echo '{ "success": false, "commands": [';
  $first = true;
  foreach($commands as $item) {
    if($first) {
      $first = false;
    } else {
      echo ",";
    }
    echo '"' . $item . '"';
  }
  echo '] }';
  exit(0);
}

if ($command == "modify") {
	if($con == "") {
	  echo '{ "success": false, "missing_params": "con" }';
	  exit(0);
	}
	if($ssid) {
		$answer = shell_exec("sudo nmcli connection modify " . $con . " 802-11-wireless.ssid " . $ssid );
	}
	if($pass) {
		$answer = shell_exec("sudo nmcli connection modify " . $con . " 802-11-wireless-security.psk " . $pass );
	}
	if($ssid == "" and $pass = "") {
		echo '{ "success": false, "missing_params": [ "ssid", "pass" ] }';
		exit(0);
	}
	shell_exec("sudo nmcli connection down " . $con . " && sudo nmcli connection up " . $con);

	echo '{ "success": true }';
}
if ($command == "show") {
	if($con == "") {
	  echo '{ "success": false, "missing_params": "con" }';
	  exit(0);
	}
	$ssid_o = shell_exec("sudo nmcli -f 802-11-wireless.ssid connection show " . $con );
	$ssid = trim(explode(":", $ssid_o, 2)[1]);
	$pass_o = shell_exec("sudo nmcli -f 802-11-wireless-security.psk -s connection show " . $con );
	$pass = trim(explode(":", $pass_o, 2)[1]);
	echo '{ "success": true, "ssid": "' . $ssid . '", "pass": "' . $pass . '" }';
}

?>
