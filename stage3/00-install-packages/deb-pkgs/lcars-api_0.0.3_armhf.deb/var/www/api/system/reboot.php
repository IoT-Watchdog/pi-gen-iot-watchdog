<?php
shell_exec("/usr/bin/sudo /sbin/shutdown -r now");
echo '{ "success": true, "shutdown": "reboot" }';
?>
