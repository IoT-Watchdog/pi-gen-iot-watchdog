<?php


if(! isset($_GET["gpio"])) {
  echo '{ "error": "param gpio (BCM number) not given" }';
  exit(0);
}
$gpio = $_GET["gpio"];

if(! isset($_GET["status"])) {
  $status = "";
  $direction = trim(exec("gpio readall | grep -o -e '^[[:space:]]|[[:space:]]*".$gpio.".*||' -e '||.*".$gpio."[[:space:]]*|$'|grep -o -E 'OUT|IN'"));
  if($direction == "OUT") {
    $value = trim(exec("gpio -g read " . $gpio));
    if($value == "1") {
      $status = ', "status": "high"';
    } else {
      $status = ', "status": "low"';
    }
  } elseif ($direction == "IN ") {
    $status = ', "status": "float"';
  } else {
    echo '{ "error": "param gpio (BCM number) not given" }';
    exit(0);
  }
  echo '{ "success": true, "gpio":'.$gpio.',"direction":"'.$direction.'"' . $status . '}';
  exit(0);
}
$status = $_GET["status"];

if($status == "high") {
  exec('gpio -g mode '.$gpio.' output');
  exec('gpio -g write '.$gpio.' 1');
  echo '{ "success": true, "gpio":'.$gpio.',"status": "high" }';
  exit(0);
}
if($status == "low") {
  exec('gpio -g mode '.$gpio.' output');
  exec('gpio -g write '.$gpio.' 0');
  echo '{ "success": true, "gpio":'.$gpio.',"status": "low" }';
  exit(0);
}
if($status == "float") {
  exec('gpio -g mode '.$gpio.' input');
  echo '{ "success": true, "gpio":'.$gpio.',"status": "float" }';
  exit(0);
}

echo '{ "error": "status must be high, low or float" }';


?>
