<?php
$uptimestring  = exec ('uptime -p');
echo '{ "success": true, "uptime": "'.substr($uptimestring, 3).'" }';
?>
