<?php

$all_dev[0x03] = "ams AS3935 (lightning/EMP)";
$all_dev[0x10] = "Vishay VEML6075 (UVA/-B/Vis/IR)";
$all_dev[0x29] = "ams TCS34725 (RGB)";
$all_dev[0x33] = "Melexis MLX90640 (32x24px FIR-Cam)";
$all_dev[0x39] = "ams TSL2561 (brightn)";
$all_dev[0x40] = "TI INA219 (current/voltage)";
$all_dev[0x43] = "ams ENS210 (T/rH)";
$all_dev[0x44] = "Sensirion SHT31 (T/rH)";
$all_dev[0x45] = "Sensirion SHT31 (T/rH)";
$all_dev[0x48] = "TI ADS1b15 (4ch ADC) addr=low";
$all_dev[0x49] = "TI ADS1b15 (4ch ADC) addr=high";
$all_dev[0x4a] = "TI ADS1b15 (4ch ADC) addr=SDA";
$all_dev[0x4b] = "TI ADS1b15 (4ch ADC) addr=SCL";
$all_dev[0x50] = "generic EEPROM";
$all_dev[0x51] = "generic EEPROM";
$all_dev[0x52] = "generic EEPROM";
$all_dev[0x53] = "generic EEPROM";
$all_dev[0x54] = "generic EEPROM";
$all_dev[0x55] = "generic EEPROM";
$all_dev[0x56] = "generic EEPROM";
$all_dev[0x57] = "generic EEPROM (from RTC)";
$all_dev[0x58] = "Sensirion SGP30 (VOC/eCO₂)";
$all_dev[0x5a] = "ams CCS810 (VOC/eCO₂) addr=low OR ams iAQ-Core (VOC/eCO₂)";
$all_dev[0x5b] = "ams CCS810 (VOC/eCO₂) addr=high";
$all_dev[0x61] = "Sensirion SCD30 (CO₂/T/rH)";
$all_dev[0x68] = "generic RTC OR Invensense MPU9250 (9DOF: Acc/Gyro/Hall) addr=low";
$all_dev[0x69] = "Invensense MPU9250 (9DOF: Acc/Gyro/Hall) addr=high OR Sensirion SPS30 (PM)";
$all_dev[0x76] = "Bosch BME280 (Hygro/Thermo/Baro)";
$all_dev[0x77] = "Bosch BME680 (Hygro/Thermo/Baro/VOC) OR Bosch BME280 (Hygro/Thermo/Baro)";

$all_dev[0xFF] = "";

echo '{'."\n".'  "success": true,'."\n".'  "result": {'."\n";

$i2cBusses = [];
$i2cDevs = trim(shell_exec("ls /dev/i2c-* -1"));
$dev_array = explode("\n", $i2cDevs);
foreach($dev_array as $i2cDev) {
  $number = explode("-",$i2cDev)[1];
  array_push($i2cBusses, $number);
}
foreach ($i2cBusses as $i2cBus) {
  if($i2cBus != "0" and sizeof($i2cBusses) > 1 ) echo ",";
  echo '    "/dev/i2c-'.$i2cBus.'": {'."";
  

  $i2c_devices=exec("sudo /usr/sbin/i2cdetect -y " . $i2cBus . " | tail -n +2 |sed 's/^....//g'| sed -z 's/\\n//g'");
  $dev_array = explode(" ",ltrim($i2c_devices));

  $dev_count=3;
  if($i2c_devices) {
    $first = true;
    foreach($dev_array as $device) {
  
      if($device != "--") {
        if(!$first) {
          echo ",";
        }
        $first = false;
        echo "\n";
        if(! array_key_exists($dev_count, $all_dev)) {
          $all_dev[$dev_count] = "unknown";
        }
        echo sprintf("      \"0x%x\": \"%s\"", $dev_count, $all_dev[$dev_count]);
      }
      $dev_count++;
    }
  } else
    echo "      { \"error\": \"i2c bus ".$i2cBus." not accessible\"";

  if(!$first) {
    echo "\n";
  }
  echo "    }\n";
}
echo "  }\n";
echo "}\n";
?>
