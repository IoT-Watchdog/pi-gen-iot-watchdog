<?php
//detect if running on koffer or Henri1
$rot = "-rot 270";

exec('raspivid -t 0 -w 480 -h 700 '.$rot.' -p 0,40,480,700 -o - > /dev/null &');

echo '{ "success": true, "cameraRunning": true }';
?>
