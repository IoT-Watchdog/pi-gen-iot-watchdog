<?php

exec ('killall raspivid');

$date=exec('date "+%Y-%m-%d_%H-%M-%S"');
$rot = "";

$folder = "../../ng/images/";
exec ('mkdir -p ' . $folder);
$filename = $date . ".jpg";
$filepath = $folder . $filename;
$retval = exec('raspistill -t 1 -q 100 -w 3280 -h 2464 '.$rot.' -n -o ' . $filepath);

echo '{ "success": true, "filename": "' . $filename . '" }';
?>
