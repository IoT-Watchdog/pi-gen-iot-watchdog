<?php

$ir = $_GET["irstatus"];

if(! $ir) {
  echo '{ "error": "param irstatus [on|off|auto] not given" }';
  exit(0);
}

if($ir == "on") {
  exec('gpio -g mode 22 output');
  exec('gpio -g write 22 1');
  echo '{ "success": true, "ledstatus": "on" }';
  exit(0);
}
if($ir == "off") {
  exec('gpio -g mode 22 output');
  exec('gpio -g write 22 0');
  echo '{ "success": true, "ledstatus": "off" }';
  exit(0);
}
if($ir == "auto") {
  exec('gpio -g mode 22 input'); # floating
  echo '{ "success": true, "ledstatus": "auto" }';
  exit(0);
}
 
?>
