<?php
$retVal = 1;
$retArr = [];

exec('gpio -g mode 22 output');
exec('gpio -g write 22 0');

exec('killall raspivid 2>&1',$retArr, $retVal);

if($retVal == 0) {
  echo '{ "success": true, "cameraRunning": false }';
} else {
  echo '{ "success": false }';
}
?>
