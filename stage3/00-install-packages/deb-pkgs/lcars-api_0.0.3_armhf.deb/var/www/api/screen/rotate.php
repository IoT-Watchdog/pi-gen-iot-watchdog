<?php 
$deg = $_GET["deg"];
if ($deg) {
  #echo "posted bn: " . $nbn . "\n";

  $ibn = strval($deg);
  $xrand_arg = "0";
  if ( $deg == 90) {
    $xrand_arg = "1";
  } elseif ( $deg == 180) {
    $xrand_arg = "2";
  } elseif ( $deg == 270) {
    $xrand_arg = "3";
  } elseif ( $deg != 0) {
    echo '{ "error": "param deg must be one of 0 90 180 270" }';
  }

  $cmd = "DISPLAY=:0 xrandr -o " + $xrand_arg;
  $ret = system($cmd);
}

$xrandr_output = exec('xrandr -q|grep " connected"|cut -f 1 -d "("');
$xr_o_arr = explode(" ", $xrandr_output);
$rot = $xr_o_arr[sizeof($xr_o_arr) -1];
$degs = "0";
if($rot == "inverted") {
  $degs = "180";
} elseif($rot == "left") {
  $degs = "90";
} elseif($rot == "right") {
  $degs = "270";
}
echo '{ "rotation_deg":' . $degs . '}';

?>
