<?php 
$nbn = $_GET["bn"];
if ($nbn) {
  #echo "posted bn: " . $nbn . "\n";

  $ibn = strval($nbn);
  #echo $ibn;

  #if( $ibn < 256 && $ibn > 7) {
  if( $ibn < 256 && $ibn >= 0) {
    $cmd = "echo " . $nbn . " > /sys/class/backlight/rpi_backlight/brightness";
 #   echo $cmd;
    $ret = system($cmd);
   # echo $ret;
  } else {
    echo '{ "error": "param bn [0-255] out of range" }';
  }
} else {
  echo '{ "error": "param bn [0-255] not given" }';
}
?>
