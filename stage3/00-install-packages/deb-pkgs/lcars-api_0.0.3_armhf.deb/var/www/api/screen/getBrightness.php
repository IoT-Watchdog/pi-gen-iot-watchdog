<?php 
$bnfile = '/sys/class/backlight/rpi_backlight/brightness';

if(file_exists($bnfile)) {
  $bn = file_get_contents($bnfile);
  echo '{ "success": true, "brightness": ' . trim($bn) . ' }';
} else {
  echo '{ "success": false }';
}

?>
