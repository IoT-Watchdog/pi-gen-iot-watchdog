<?php
require_once 'vendor/autoload.php';
use GeoIp2\Database\Reader;

// This creates the Reader object, which should be reused across
// lookups.
$reader = new Reader('GeoIP/GeoLite2-City.mmdb');

if(isset($_GET['ip'])) {
	$ip = $_GET['ip'];
} else {
        echo '{ "success": false }';
        exit(0);
	$ip = "129.27.2.3";
	$ip = "91.143.92.102";
	$ip = "172.217.22.42";
	$ip = "216.58.205.234";
}

// Replace "city" with the appropriate method for your database, e.g.,
// "country".
try {
	$record = $reader->city($ip);
} catch (Exception $e) {
	echo '{ "success": false, "Exception": "' . $e->getMessage() . '" }';
        exit(0);
}
print("\n");
# var_dump($record);
print '{
  "IP":"' . $ip . '",
  "isoCode":"' . $record->country->isoCode . '",
  "country":"' . $record->country->name . '",
  "country:de":"' . $record->country->names['de'] . '",
  "state":"' . $record->mostSpecificSubdivision->name . '",
  "city":"' . $record->city->name . '",
  "postcode":"' . $record->postal->code . '",
  "lat":' . $record->location->latitude . ',
  "lon":' . $record->location->longitude . "\n}";

exit(0);

print("\n");
print($record->country->isoCode . "\n"); // 'US'
print($record->country->name . "\n"); // 'United States'
# print($record->country->names['zh-CN'] . "\n"); // '美国'

print($record->mostSpecificSubdivision->name . "\n"); // 'Minnesota'
print($record->mostSpecificSubdivision->isoCode . "\n"); // 'MN'

print($record->city->name . "\n"); // 'Minneapolis'

print($record->postal->code . "\n"); // '55455'

print($record->location->latitude . "\n"); // 44.9733
print($record->location->longitude . "\n"); // -93.2323

print($record->traits->network . "\n"); // '128.101.101.101/32'
?>
