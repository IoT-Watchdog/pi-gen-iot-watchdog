<?php
$ip = $_GET["ip"];
$hn = shell_exec("node whois2json.js " . $ip);
echo $hn;
?>
