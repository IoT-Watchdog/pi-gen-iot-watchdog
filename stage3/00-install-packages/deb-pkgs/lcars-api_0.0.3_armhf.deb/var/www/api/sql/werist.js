const werist = require('werist')
werist.lookup('129.27.2.3', function(err, data) {
  console.log(data)
})
