<?php
header('Access-Control-Allow-Origin: *');

$servername = "localhost";
$username   = "root";
$password   = "jKD7ubqVeg";
$dbname     = "ntopng";

$limit = "25";
if (isset($_GET["limit"])) {
    $limit = $_GET["limit"];
}


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error);
} 


//echo "Connected successfully";
$sql = "SELECT * FROM `flowsv4` ORDER BY `LAST_SWITCHED` DESC LIMIT " . $limit;
$result = mysqli_query($conn,$sql); 
#echo 'res succ';
$myArray = array();
if ($result->num_rows > 0) {
// output data of each row
 while($row = $result->fetch_assoc()) {
     unset($row["JSON"]);
     $myArray[] = $row;
     #print_r($myArray);
 }
 print '{ "result":';
 print json_encode($myArray);
 print '}';
} 
else 
{
 echo '{ "results": 0 }';
}
