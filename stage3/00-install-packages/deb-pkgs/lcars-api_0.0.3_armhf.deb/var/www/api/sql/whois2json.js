const whois = require('whois-to-json');

whois('129.27.2.3')
  .then(data => {
    console.log(JSON.stringify(data, null, 2));
  })
  .catch(console.error);
