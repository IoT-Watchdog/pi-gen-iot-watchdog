var whois = require('whois')
whois.lookup('amazon.at', function(err, data) {
	console.log(data)
})
