'use strict'
const whois = require('node-xwhois');
 
const host1 = 'xinit.ru';
const host2 = '8.8.8.8';
 
whois.geoInit('GeoIP') // symlink
.then(() => {
    whois.hostInfo(host1)
    .then(data => console.log(`${host1} info:\n`, JSON.stringify(data, null, 4)))
    .catch(err => console.log(err));
 
    whois.hostInfo(host2)
    .then(data => console.log(`${host2} info:\n`, JSON.stringify(data, null, 4)))
    .catch(err => console.log(err));
})
.catch(err => console.log(err));
