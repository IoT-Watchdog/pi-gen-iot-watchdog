One possibility to get CC-licensed icons:
1. Google Image search
2. click “Tools” and then click “Usage Rights” you can select from one of many Creative Commons licenses to search through. (tip from https://1stwebdesigner.com/creative-commons-icons/)

https://thenounproject.com/ - there is a free account option
choose basic download
  its Creative Commons Attribution then
  use inscape to remove the inset text
  export svg first
    somehow add attribution text (meta tags?)
